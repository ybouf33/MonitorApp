
# NMonitorPro/urls.py
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
urlpatterns = [
    path('', lambda request: redirect('login')),

     # Django admin
    path('admin/', admin.site.urls),

    # Authentication app (login, register, etc.)
    path('auth/', include('authentication.urls')),

    # Device management app (CRUD for devices)
    path('devices/', include('devices.urls')),

    # Monitoring app (real-time monitoring of devices)
    path('monitoring/', include('monitoring.urls')),

    # Configuration management app (upload and manage device configs)
    path('configuration/', include('configuration.urls')),

    # Notifications app (alert preferences, notifications)
    path('notifications/', include('notifications.urls')),

    # Reports app (generate and view network reports)
    path('reports/', include('reports.urls')),

    # Home or Dashboard view (can be defined in any of your apps, e.g., monitoring)
    path('', include('monitoring.urls')),  # Home route can point to monitoring dashboard
   
]
