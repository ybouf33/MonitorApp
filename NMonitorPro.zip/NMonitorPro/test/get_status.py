import os
from time import sleep

hosts = ["10.10.10.10", "salesforce.com", "google.com", "cisco.com"]
pause = 2
success_indicator = "bytes from"  # More reliable indicator for successful ping

header = """
<meta http-equiv='refresh' content='10'>
<title>Up/Down App</title>
<h1>Network Monitor</h1>
"""

while True:
    body = "<table border='1' cellpadding='10'>\n"
    
    for host in hosts:
        body += "\t<tr>\n"
        command = f"ping -c 1 {host}"
        response = os.popen(command).read()

        if success_indicator in response:
            print(f"{host} is UP")
            body += f"\t\t<td style='background-color:lightgreen;'>{host} is UP</td>\n"
        else:
            print(f"{host} is DOWN")
            body += f"\t\t<td style='background-color:red;'>{host} is DOWN</td>\n"
        
        body += "\t</tr>\n"

    body += "</table>\n"

    # Combine header and body
    html_content = header + body
    
    # Write HTML content to a file
    with open("network_status.html", "w") as f:
        f.write(html_content)

    # Wait for the specified pause interval before repeating
    sleep(pause)
