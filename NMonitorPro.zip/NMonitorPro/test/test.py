import paramiko
import time
from concurrent.futures import ThreadPoolExecutor

def monitor_device(device):
    hostname = device['hostname']
    username = device['username']
    password = device['password']
    device_type = 'cisco_ios'

    try:
        # Establish SSH connection
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(hostname, username=username, password=password, timeout=10)

        # Commands to run based on device type
        commands = {
            'router': ['show version', 'show ip interface brief', 'show cpu usage'],
            'switch': ['show version', 'show interfaces status', 'show mac address-table'],
            'firewall': ['show version', 'show interface', 'show cpu'],
            'access_point': ['show version', 'show wireless summary', 'show client summary']
        }

        results = []
        for command in commands.get(device_type, []):
            stdin, stdout, stderr = ssh.exec_command(command)
            output = stdout.read().decode('utf-8')
            results.append(f"Command: {command}\nOutput:\n{output}\n")

        ssh.close()
        return f"Device: {hostname} ({device_type})\n" + "-" * 50 + "\n" + "\n".join(results)

    except Exception as e:
        return f"Error monitoring {hostname} ({device_type}): {str(e)}"

def monitor_network(devices):
    with ThreadPoolExecutor(max_workers=10) as executor:
        results = list(executor.map(monitor_device, devices))
    
    for result in results:
        print(result)
        print("=" * 80 + "\n")

if __name__ == "__main__":
    devices = [
        {'hostname': '10.10.10.10', 'username': 'cisco', 'password': 'cisco', 'type': 'router'},
        {'hostname': '10.100.224.253', 'username': 'cisco', 'password': 'cisco', 'type': 'switch'},
  
    ]

    monitor_network(devices)
