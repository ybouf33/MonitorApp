from netmiko import ConnectHandler
import re

# Function to parse the interfaces configuration
def parse_interfaces(interfaces_config):
    parsed_interfaces = []

    # Matching interface patterns
    pattern = re.compile(r"^interface\s\S+$")

    for line in interfaces_config.splitlines():
        if pattern.match(line):
            interface = {"interface": line.split(" ")[1]}
            parsed_interfaces.append(interface)
        elif line.startswith(" description"):
            parsed_interfaces[-1]["description"] = " ".join(line.split(" ")[1:])
        elif line.startswith(" switchport access vlan"):
            parsed_interfaces[-1]["vlan"] = line.split(" ")[4]
        elif line.startswith(" switchport mode access"):
            parsed_interfaces[-1]["mode"] = "access"
        elif line.startswith(" shutdown"):
            parsed_interfaces[-1]["shutdown"] = True
        elif line.startswith(" ip address"):
            parsed_interfaces[-1]["ip_address"] = line.split(" ")[3]  # IP address
        elif line.startswith(" end"):
            break

    return parsed_interfaces


# Connection parameters
switch = {
    "device_type": "cisco_ios",
    "ip": "10.100.224.253",
    "username": "cisco",
    "password": "cisco",&²  
}

# Establish SSH connection to the switch
ssh_connection = ConnectHandler(**switch)

# Retrieve running configuration from the switch
output = ssh_connection.send_command("show run")

# Extract interfaces configuration from the output
interfaces_config = ""
in_interfaces = False
for line in output.splitlines():
    if line.startswith("interface "):
        in_interfaces = True
    elif in_interfaces and line.startswith("!"):
        in_interfaces = False
    if in_interfaces:
        interfaces_config += line + "\n"

# Parse interfaces configuration
interfaces = parse_interfaces(interfaces_config)

# Print interfaces info
for interface in interfaces:
    print("Interface:", interface["interface"])
    print("IP Address:", interface.get("ip_address", "N/A"))
    print("Description:", interface.get("description", "N/A"))
    print("VLAN:", interface.get("vlan", "N/A"))
    print("Mode:", interface.get("mode", "N/A"))
    print("Shutdown:", "Yes" if interface.get("shutdown") else "No")
    print("-" * 30)
