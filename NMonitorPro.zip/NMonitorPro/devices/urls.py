from django.urls import path
from . import views

urlpatterns = [
    path('', views.device_list, name='device_list'),  # Main device list view
    path('get_device_status/', views.get_device_status, name='get_device_status'),  # Real-time status view
    path('network_topology_view/', views.network_topology_view, name='network_topology_view'),  # Real-time status view
]
