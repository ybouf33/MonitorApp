from django.db import models

class Device(models.Model):
    name = models.CharField(max_length=100)
    ip_address = models.GenericIPAddressField()
    mac_address = models.CharField(max_length=17, unique=True,blank=True,null=True)  # MAC address (XX:XX:XX:XX:XX:XX)
    device_type = models.CharField(max_length=50)
    model = models.CharField(max_length=50, blank=True, null=True)  # Optional device model
    serial_number = models.CharField(max_length=50, blank=True, null=True)  # Optional serial number
    location = models.CharField(max_length=100, blank=True, null=True)  # Optional device location
    status = models.BooleanField(default=False)  # Checkbox: True = Online, False = Offline
    last_checked = models.DateTimeField(null=True, blank=True)  # When the device was last checked

    def __str__(self):
        return self.name
