import subprocess
from django.http import JsonResponse
from django.utils import timezone
from .models import Device
from django.shortcuts import render
import re
def ping_device(ip_address):
    """
    Returns True if the device is reachable (online), False if not.
    """
    try:
        output = subprocess.run(
            ['ping', '-c', '1', '-W', '1', ip_address],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return output.returncode == 0
    except Exception:
        return False

def device_list(request):
    devices = Device.objects.all()
    return render(request, 'devices/device_list.html', {'devices': devices})

def get_device_status(request):
    devices = Device.objects.all()
    # Create a list of device data to return as JSON
    device_data = []
    for device in devices:
        status = ping_device(device.ip_address)  # Assuming you have a function to check device status
        
        # Check if the status has changed, update the last checked timestamp
        if device.status != status:
            device.status = status
            device.last_checked = timezone.now()
            device.save()  # Save changes if status changed
        
        # Add device information to the list for the response
        device_data.append({
            'id': device.id,
            'name': device.name,
            'ip_address': device.ip_address,
            'device_type': device.device_type,  # Include the device type field
            'status': device.status,  # Updated status
            'last_checked': device.last_checked.strftime('%Y-%m-%d %H:%M:%S')  # Format for JSON response
        })
    
    # Return the list of device data as JSON
    return JsonResponse(device_data, safe=False)





def parse_cdp_neighbors(cdp_output):
    """
    Parse the 'show cdp neighbors' output and return a list of connections.
    Each connection will be represented as a dictionary with keys:
    - 'device_id': The neighbor device's ID
    - 'local_interface': The local interface connecting to the neighbor
    - 'port_id': The port ID on the neighbor device
    - 'capability': The capability of the neighbor (e.g., Router, Switch)
    - 'platform': The neighbor's platform information
    """
    neighbors = []
    lines = cdp_output.strip().splitlines()
    for line in lines[2:]:  # Skip the header lines
        # Example line format:
        # ESW1.cisco       Fas 0/1       91        S I      2691      Fas 0/0
        match = re.match(r"(\S+)\s+(\S+)\s+\S+\s+(\S+)\s+(\S+)\s+(\S+)", line)
        if match:
            neighbors.append({
                'device_id': match.group(1),
                'local_interface': match.group(2),
                'capability': match.group(3),
                'platform': match.group(4),
                'port_id': match.group(5),
            })
    return neighbors

def network_topology_view(request):
    # Sample 'show cdp neighbors' output (in practice, you could fetch this from the devices)
    cdp_output = """
    Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
    ESW1.cisco       Fas 0/1            91           S I      2691      Fas 0/0
    R1.cisco         Fas 0/2            123          R        1800      Fas 0/1
    SW2.cisco        Fas 0/3            125          S        2960      Fas 0/2
    """
    
    # Parse the CDP neighbors output
    neighbors = parse_cdp_neighbors(cdp_output)

    # Pass the neighbors data to the template
    return render(request, 'devices/network_topology.html', {'neighbors': neighbors})
