from django.contrib import admin
from .models import Device
from unfold.admin import ModelAdmin

@admin.register(Device)
class DeviceAdmin(ModelAdmin):
    list_display = ('name', 'ip_address', 'mac_address', 'device_type', 'serial_number', 'status', 'last_checked')
    search_fields = ('name', 'ip_address', 'mac_address', 'device_type', 'serial_number')
    list_filter = ('device_type', 'status')
    ordering = ('name',)

# admin.site.register(Device, DeviceAdmin)
