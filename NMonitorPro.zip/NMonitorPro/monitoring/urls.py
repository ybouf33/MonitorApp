from django.urls import path
from .views import dashboard
from django.http import HttpResponse
urlpatterns = [
    path('dashboard/', dashboard, name='dashboard'),
]
